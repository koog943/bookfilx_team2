package com.edu.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
