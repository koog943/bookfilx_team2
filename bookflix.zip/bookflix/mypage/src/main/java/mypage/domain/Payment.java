package mypage.domain;

public class Payment {
    
}
